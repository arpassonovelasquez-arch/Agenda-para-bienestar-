package com.agenda.bienestar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AgendaScreen()
                }
            }
        }
    }
}

@Composable
fun AgendaScreen() {
    var items by remember { mutableStateOf(listOf<String>()) }
    var text by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Agenda Bienestar", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Nuevo evento") }
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            if (text.isNotBlank()) {
                items = items + text
                text = ""
            }
        }) {
            Text("Agregar")
        }
        Spacer(Modifier.height(16.dp))
        items.forEachIndexed { idx, it ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(it)
                TextButton(onClick = { items = items.filterIndexed { i, _ -> i != idx } }) {
                    Text("Eliminar")
                }
            }
        }
    }
}
